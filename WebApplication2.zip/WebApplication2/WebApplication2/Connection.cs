﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication2
{
    public static class Connection
    {
        public static SqlConnection con;
        public static SqlConnection getcon()
        {
            if(con==null)
            {
                con = new SqlConnection();
                con.ConnectionString = @"Data Source=DESKTOP-JST71CC\SOHAIB;Initial Catalog=SuperMartDollarStore;Integrated Security=True";
                con.Open();
            }
            return con;
        }
    }
}