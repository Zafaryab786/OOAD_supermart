﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication2.Controllers
{
    public class SUPERMARTController : Controller
    {
        // GET: SUPERMART
        [HttpGet]
        public ActionResult displays()
        {
            return View();
        }
        [HttpPost]
        public ActionResult inserts(SUPERMART s)
        {
            s.inserts(s);
            return View();
        }
    }
}