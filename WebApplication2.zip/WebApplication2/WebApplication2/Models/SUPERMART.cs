﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication2.Controllers
{
    public class SUPERMART
    {

        public int invoiceNo { get; set; }
        public string userName { get; set; }
        public string SelectedItems { get; set; }
        public int unitprice { get; set; }
        public int Discountperitem { get; set; }
        public int Quantity { get; set; }

        internal void inserts(SUPERMART s)
        {
            throw new NotImplementedException();
        }

        public int Tax { get; set; }
        public int TotalCost { get; set; }
        public int FinalCost { get; set; }

        public int AmountPaid { get; set; }
        public int Change { get; set; }
        public void displays(SUPERMART s)
        {

            string query1 = string.Format("insert into SUPERMART values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')", s.invoiceNo,s.userName,s.SelectedItems,s.unitprice,s.Discountperitem,s.Quantity,s.TotalCost,s.FinalCost,s.Tax,s.AmountPaid,s.Change);
            SqlCommand cmd = new SqlCommand(query1, Connection.getcon());
            cmd.ExecuteNonQuery();
        }
    }
}